#ifndef CACCOUNT_H
#define CACCOUNT_H
#include <cstring>
#include <iostream>
#include <cstdio>
using namespace std;
#include "cmoney.h"
#include "ccustomer.h"

/*
Muss auf CMoney balance zugreifen
balance besteht aus amount aus CMoney
Bezug zu {CCustomer *customer}
Bezug zu {CBooking *bookingList[]}
*/

class CCustomer;

class CAccount
{
  private:
	string iban;
	CMoney balance;
	CCustomer *customer;

  public:
  CAccount();
  CAccount(string iban ="DE69100500009082198374", CMoney balance=150.0);

  void setIban(string iban);
  string getIban(){return iban;}

  void setBalance(CMoney balance);
  CMoney getBalance(){return balance;}


  void setCustomer(CCustomer *customer);
  CCustomer* getCustomer(){return customer;}

  void print();
};


#endif

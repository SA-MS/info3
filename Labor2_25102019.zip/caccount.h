#ifndef CACCOUNT_H
#define CACCOUNT_H
#include <cstring>
#include <iostream>
#include <cstdio>
using namespace std;
#include "cmoney.h"

/*
Muss auf CMoney balance zugreifen
balance besteht aus amount aus CMoney
Bezug zu {CCustomer *customer}
Bezug zu {CBooking *bookingList[]}
*/

class CAccount
{
  private:
	string iban;
	CMoney balance;
	CCustomer *customer;

  public:
  CAccount();
  CAccount(string iban ="DE69100500009082198374", CMoney balance);
  void setIban(string iban);
  string getIban(){return iban;}
  void setBalance(CMoney balance);
  CMoney balance(){return balance;}
  void setCutsomer(CCustomer *customer);
  CCustomer *cus
  void print();
};


#endif

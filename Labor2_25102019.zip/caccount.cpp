#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <iostream>
#include "caccount.h"
using namespace std;

void CAccount::print()
{
  printf("%s", iban.c_str());
}

CAccount::CAccount()
:iban ("DE123456781234567890") {}

CAccount::CAccount(string iban)
:iban (iban){}

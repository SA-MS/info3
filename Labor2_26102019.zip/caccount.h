#ifndef CACCOUNT_H
#define CACCOUNT_H
#include <cstring>
#include <iostream>
#include <cstdio>
using namespace std;
#include "cmoney.h"
#include "ccustomer.h"

/*
Muss auf CMoney balance zugreifen
balance besteht aus amount aus CMoney
Bezug zu {CCustomer *customer}
Bezug zu {CBooking *bookingList[]}
*/

class CCustomer;

class CAccount
{
  private:
	string iban;
	CMoney balance;
	CCustomer *customer;

  public:
  CAccount();
  CAccount(string iban,CCustomer *customer ,CMoney balance);

  void setIban(string iban);
  string getIban(){return iban;}

  void setBalance(CMoney balance);
  CMoney getBalance(){return balance;}


  void setCustomer(CCustomer *customer);
  CCustomer* getCustomer(){return customer;}

  void print();
};


#endif

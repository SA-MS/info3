#include <iostream>
#include <cstdio>
#include <cstring>
#include <iomanip>

// Eigene Header
#include "ccurrentaccount.h"
#include "csavingaccount.h"
#include "caccount.h"
#include "ccustomer.h"
#include "cmoney.h"
#include "cbank.h"
//Vorwärtsdeklaration
class CAccount;
class CMoney;

void CSavingsAccount::print()
{
    printf("Kunde: ");
    printCustomername();
    printCustomerid();
    printf("IBAN / BIC: ");
    printiban();
    printf(" / ");
    printbank();
    printf(" / ");
    printf("\nKontostand: ");
    printCustomerbalance();
    printf("\nZinsen: ");
    printZinsen();
}

void CSavingsAccount::printZinsen()
{
    cout << getZinsen() << " %";
//    printf("%4.2ld", getZinsen());
}


// -------------------------- Konstruktoren -----------------------------------------

// Kein Standardkonstruktor


/** Konstruktor**/
CSavingsAccount::CSavingsAccount(CBank* bank, string iban, CCustomer *customer, CMoney balance, double zinsen)
    : CAccount(bank, iban, customer, balance), zinsen(zinsen){}
    // Von CAccount vererbt                    Aus CMoney vererbt

/** Destruktor **/

CSavingsAccount::~CSavingsAccount()
{
    cout << left << setw(20) << "CSavingsaccount:" << setw(8) << "Konto: (";
    printiban();
    cout << ") wurde vernichtet!" << endl;
}

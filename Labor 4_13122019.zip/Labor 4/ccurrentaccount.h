#ifndef CCURRENTACCOUNT_H
#define CCURRENTACCOUNT_H

#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

// Eigene Header
#include "cmoney.h"
#include "caccount.h"
// Vorwärtsdeklarationen
class CAccount;
class CMoney;


class CCurrentAccount: public CAccount
{
    private:
        CMoney* dispo;

    public:
        CCurrentAccount(CBank *bank, string iban, CCustomer *customer, CMoney balance, CMoney * dispo);
        ~CCurrentAccount();

    // -------------------------- Setter & Getter -----------------------------------------


    // -------------------------- Weitere Methoden -----------------------------------------
    void print();

    void printDispo();

};



#endif // CCURRENTACCOUNT_H

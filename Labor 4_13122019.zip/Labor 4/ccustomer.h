#ifndef CCUSTOMER_H
#define CCUSTOMER_H

#include <string>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <iostream>
#include "cadress.h"
#include "caccount.h"
#include "cmoney.h"
#include "cdate.h"
#define MAXACCOUNTS 10
using namespace std;

class CAccount;

class CCustomer
{
private:
    long int id;
    string name;
    CDate birthday;
    CAdress address;

    CAccount *accountList[MAXACCOUNTS];
    int zaehler;

public:
    CCustomer()
    :address("", "", ""),zaehler(0) {}
    CCustomer(long int id, string name, CDate birthday, CAdress address);
    ~CCustomer();


// -------------------------- Setter & Getter -----------------------------------------

    void setId(long int id)
    {
        this->id=id;
    }
    long int getId()
    {
        return id;
    }

    void setName(string name)
    {
        this->name=name;
    }
    string getName()
    {
        return name;
    }

    void setBirthday(CDate birthday)
    {
        this->birthday=birthday;
    }
    CDate getBirthday()
    {
        return birthday;
    }

    void setAdress(CAdress address)
    {
        this->address=address;
    }
    CAdress getAdress()
    {
        return address;
    }

// -------------------------- Weitere Methoden --------------------------------------

    void addAccount(CAccount *accountList);

    void print();

    void load(ifstream *f);
};

#endif

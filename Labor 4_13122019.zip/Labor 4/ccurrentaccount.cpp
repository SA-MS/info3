#include <iostream>
#include <cstdio>
#include <cstring>
#include <iomanip>

// Eigene Header
#include "ccurrentaccount.h"
#include "caccount.h"
#include "ccustomer.h"
#include "cmoney.h"
//Vorwärtsdeklaration
class CAccount;
class CMoney;

void CCurrentAccount::print()
{
    printf("Kunde: ");
    printCustomername();
    printCustomerid();
    printf("IBAN / BIC: ");
    printiban();
    printf(" / ");
    printbank();
    printf(" / ");
    printf("\nKontostand: ");
    printCustomerbalance();
    printf("\n");
    printf("Dispo: ");
    printDispo();
}


void CCurrentAccount::printDispo()
{
    printf("%4.2f %s", dispo->getAmount(), dispo->getCurrency().c_str());
}

// -------------------------- Konstruktoren -----------------------------------------

// Kein Standardkonstruktor


///** Konstruktor**//
CCurrentAccount::CCurrentAccount(CBank* bank, string iban, CCustomer *customer, CMoney balance, CMoney *dispo)
    : CAccount(bank, iban, customer, balance), dispo(dispo){}
    // Von CAccount vererbt                    Aus CMoney vererbt

///** Destruktor **/
CCurrentAccount::~CCurrentAccount()
{
    cout << left << setw(20) << "CCurrentaccount:" << setw(8) << "Konto: (";
    printiban();
    cout << ") wurde vernichtet!" << endl;
}

// INCLUDES
#include <cstdio>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
using namespace std;

#include "cbank.h"
#include "cbankmanager.h"
#include "ccustomer.h"



/** KONSTRUKTOREN **/
CBankManager::CBankManager(string datei)
{
    ifstream f;
    string zeile;
    f.open(datei);
    if(f)
    {
        while (!f.eof())
        {
            getline(f,zeile);
            if(zeile != "\0")       // Wenn kein Zeiilenende vorhanden
                zeile = zeile.substr(zeile.find_first_not_of(' ')); // Lösche die Leerzeichen

            if(zeile.compare(0,10, "<Customer>")) // Wenn 10 Zeichen genau mit dem string übereinstimmen
            {
                CCustomer * customer = new CCustomer;   // Erzeuge einen neuen Customer
                customer -> load(&f);                   // Load-Funktion aus CCustomer
            }

            if(zeile.compare(0,6,"<Bank>"))
            {
                CBank * bank = new CBank;
                bank -> load(&f);

            }

            /*---------------------------------------------------------
                        if(zeile.compare("<Customer>"))
                        {
                            CAccount * konto = new CAccount;
                            konto->load(&f)
                            Kunde.push_back(konto);
                        }
            *///--------------------------------------------------------
        }
    }
}


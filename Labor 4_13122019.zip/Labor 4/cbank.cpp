// Libarys
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cstdio>
#include <iomanip>
using namespace std;
// Eigene Header
#include "cbank.h"
#include "ccustomer.h"
#include "caccount.h"
#include "cmoney.h"

class CAccount;
class CMoney;

// -------------------------- Printmethoden -----------------------------------------
void CBank::print()
{
    printf("%s \nBIC: %s \n", bankname.c_str(), bic.c_str());
    printf("Anzahl der Konten: %d \n", zaehlerBank);
    printf("Kontenliste:\n");
//    printf("IBAN               | Kundenname        | Anz. Buchungen | Kontostand");
    cout << left << setw(30) << "IBAN:" << "| " << setw(15) << "Kundenname:" << " | " << setw(16) << "Anz. Buchungen:" << " | " << setw(10) << "Kontostand:" << endl;
    cout << left << setw(30) << "------------------------------|-----------------|------------------|------------" << endl;
    for(int i=0; i<zaehlerBank; i++)
    {
    Kontoliste[i]->printiban();
    cout << setw(5) << ("   | ");
    Kontoliste[i]->printCustomername();
    cout << left << setw(22) << "   | 0" << setw(2) << "|";
    Kontoliste[i]->printCustomerbalance();
    printf("\n");
    }
}

void CBank::printbank()
{
    printf("%s", bic.c_str());
}

void CBank::printbankname()
{
    printf("%s", bankname.c_str());
}

void CBank::addKonto(CAccount *Konto)
{
    Kontoliste[zaehlerBank] = Konto;
    zaehlerBank++;
}

void CBank::load(ifstream *f)
{
    string line;
    do
    {
        getline(*f,line);
        if(line.size() > 0)                     // Wenn Zeichen vorhanden
        {
         if (line[line.length()] == '\r')       // /r springt an Zeilenanfang
        line.erase(line.length() - 1, 1);

            line = line.substr(line.find_first_not_of(' '));    // Leerzeichen löschen
            line.erase(line.length() -1, 1);                    //
        }

        if (line.substr(0,6).compare("<Bank>") == 0)
            cout << "CBank: " <<  line << endl;

    }
    while(line.compare(0,7,"</Bank>") != 0);

}

// -------------------------- Konstruktoren -----------------------------------------
CBank::CBank(string bankname, string bic/**, CAccount *Konten*/)
:bankname (bankname), bic (bic), zaehlerBank(0) /**, konten (konten) **/
{ /**Konten->addBankaccount(this); **/
}

#ifndef CACCOUNT_H
#define CACCOUNT_H
#include <cstring>
#include <iostream>
#include <cstdio>
using namespace std;
#include "cmoney.h"
#include "ccustomer.h"
#include "cbank.h"

// Vorwärtsdeklarationen
class CCustomer;
class CBank;

class CAccount
{
private:
        CBank *bank;
    string iban;
    CMoney balance;
    CCustomer *customer;


public:
    CAccount();
    CAccount(CBank *bank, string iban, CCustomer * customer, CMoney balance);
    ~CAccount();

// -------------------------- Setter & Getter -----------------------------------------
    void setIban(string iban)
    {
        this->iban=iban;
    }
    string getIban()
    {
        return iban;
    }

    void setBalance(CMoney balance)
    {
        this->balance=balance;
    }
    CMoney getBalance()
    {
        return balance;
    }
    void setCustomer(CCustomer* customer)
    {
        this->customer=customer;
    }
    CCustomer* getCustomer()
    {
        return customer;
    }

    void setBank(CBank *bank)
    {
        this->bank=bank;
    }
    CBank* getBank()
    {
        return bank;
    }
// -------------------------- Weitere Methoden -----------------------------------------
    void printiban();   /** CCustomer **/


    void printbank();   /** CBank     **/

    void printCustomername();   /** CCustomer **/

    void printCustomerid();  /** CCustomer **/

    void printCustomerbalance();

    void print();

//    void load();
};


#endif

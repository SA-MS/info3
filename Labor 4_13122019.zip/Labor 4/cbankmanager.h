#ifndef CBANKMANGER_H
#define CBANKMANGER_H

// INCLUDES
#include <vector>
#include <cstdio>
#include <iostream>
#include <iomanip>
using namespace std;

// EIGENE INCLUDES
#include "ccustomer.h"
#include "cbank.h"

class CCustomer;
class CBank;

class CBankManager
{
private:
    vector<CCustomer*>Kunde;
    vector<CBank*>Bank;

public:
    //Kontstruktor
    CBankManager(string datei);
};




#endif // CBANKMANAGER_H

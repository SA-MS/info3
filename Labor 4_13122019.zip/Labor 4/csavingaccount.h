#ifndef CSAVINGACCOUNT_H
#define CSAVINGACCOUNT_H

#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

// Eigene Header
#include "cmoney.h"
#include "caccount.h"
// Vorwärtsdeklarationen
class CAccount;
class CMoney;


class CSavingsAccount: public CAccount
{
    private:
        double zinsen;

    public:
        CSavingsAccount(CBank *bank, string iban, CCustomer *customer, CMoney balance, double zinsen);
        ~CSavingsAccount();

    // -------------------------- Setter & Getter -----------------------------------------


    void setZinsen(double zinsen)
    {
        this->zinsen=zinsen;
    }
    double getZinsen()
    {
        return zinsen;
    }

    // -------------------------- Weitere Methoden -----------------------------------------
    void print();

    void printZinsen();
};



#endif // CSAVINGACCOUNT_H

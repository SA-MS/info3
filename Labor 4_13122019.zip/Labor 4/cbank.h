#ifndef CBANK_H
#define CBANK_H
#define MAXACCOUNTS 10
#include "caccount.h"
class CAccount;

class CBank
{
  private:
      string bankname;
      string bic;
      CAccount *Kontoliste[MAXACCOUNTS];
      int zaehlerBank;
  public:
      CBank();
      CBank(string bankname, string bic/**, CAccount Konten**/);

// -------------------------- Setter & Getter -----------------------------------------

  void setBankname(string bankname)
  {
      this->bankname=bankname;
  }
  string getBankname()
  {
      return bankname;
  }

  void setBic(string bic)
  {
      this->bic=bic;
  }
  string getbic()
  {
      return bic;
  }

// -------------------------- Weitere Methoden -----------------------------------------
  void addKonto(CAccount *Kontoliste);

  void print();

  void printbankname();

  void printbank();

  void load(ifstream *f);
};

#endif // CBANK_H

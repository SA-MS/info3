#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include "caccount.h"
using namespace std;
#include "ccustomer.h"
#include "cbank.h"

class CCustomer;

void CAccount::print()
{
    printf("Kunde: ");
    printf("%s (Kd-Nr.: %ld)\n", customer->getName().c_str(), customer->getId());
    printf("IBAN / BIC: ");
    printiban();
    printf(" / ");
    printbank();
    printf("\nKontostand: ");
    balance.print();
}

// FÜR IBAN ALLE 4 ZEICHEN GETRENNT MODULO 4

void CAccount::printiban()
{
 for(unsigned int k=0; k<iban.length(); k++)
  {
   if(k>0&&k%4==0)
   {printf(" ");}
    printf("%c", iban[k]);
   }
}


void CAccount::printbank()
{
    printf("%s",bank->getbic().c_str());
}

void CAccount::printCustomername()
{
    cout << left << setw(13) << customer->getName().c_str() ;
//    printf("%s  ", customer->getName().c_str());
}

void CAccount::printCustomerid()
{
    printf("(Kd-Nr.: %ld) \n", customer->getId());
}

void CAccount::printCustomerbalance()
{
    balance.print();
}

/*void CAccount::load(ifstream, &f)
{
    string zeile;

    while(!f.eof())
    {
        getline(f,zeile);
        while (zeile[0] == ' ')
            zeile.erase(0, 1);

        cout << "Kunde: " << zeile << endl;

        if(zeile.compare("</Customer>")==0)
            break;
    }
    return;
} */

// -------------------------- Konstruktoren -----------------------------------------

// Standardkonstruktor
CAccount::CAccount()
    :iban ("DE123456781234567890"), balance (150.0){}

// Konstruktor
CAccount::CAccount(CBank *bank, string iban, CCustomer *customer ,CMoney balance)
    :bank(bank), iban (iban), balance (balance), customer (customer)
{
    customer->addAccount(this);
    bank->addKonto(this);
}

///** Destruktor**/
CAccount::~CAccount()
{
    cout << left <<setw(20)<< "CAccount:"<< setw(8) << "Konto: (";
    printiban();
    cout << ") wurde vernichtet!" << endl;
}

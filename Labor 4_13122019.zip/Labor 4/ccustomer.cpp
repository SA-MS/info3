#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cstring>
#include "ccustomer.h"
#include "caccount.h"

// Kein Standardkonstruktor

using namespace std;
class CAccount;
void CCustomer::print()
{
    printf("%s  (Kd-Nr.: %ld)\n", name.c_str(), id);
    address.print();
    printf("\ngeboren am: ");
    birthday.print();
    printf("\nKonten: ");

    for(int i=0; i<zaehler; i++)
    {
        printf("\n - Kontonr.: ");
        accountList[i]->printiban();
    }
}

// LOAD-METHODE
void CCustomer::load(ifstream *f)
{
    string line;
    do
    {
        getline(*f,line);
        if(line.size() > 0)                     // Wenn Zeichen vorhanden
        {
         if (line[line.length()] == '\r')       // /r springt an Zeilenanfang
        line.erase(line.length() - 1, 1);

            line = line.substr(line.find_first_not_of(' '));    // Leerzeichen löschen
            line.erase(line.length() -1, 1);                    //
        }

        if (line.substr(0,10).compare("<Customer>") == 0)
            cout << "CCustomer: " <<  line << endl;

        if (line.substr(0,4).compare("<ID>") == 0)
            cout << "CCustomer: " <<  line << endl;


        if (line.substr(0,9).compare("<Account>") == 0)
            cout << "CCustomer: " <<  line << endl;

        if (line.substr(0,10).compare("<Birthday>") == 0)
            cout << "CCustomer: " << line << endl;

        if (line.substr(0,9).compare("<Address>") == 0)
            cout << "CCustomer: " << line << endl;

       if (line.substr(0,6).compare("<Name>") == 0)
            cout << "CCustomer: " << line << endl;

//        if (line.substr(0,6).compare("<Bank>") == 0)
//            cout << "CBank: " <<  line << endl;

    }
    while(line.compare(0,10,"</Customer>") == 0);


/*


        if (line.substr(0,4).compare("<ID>") == 0)
            cout << "CCustomer: " <<  line << endl;

        if (line.substr(0,6).compare("<Name>") == 0)
            cout << "CCustomer: " <<  line << endl;

*/


}


         //if (line[line.length()] == '\r')
        //line.erase(line.length() - 1, 1);

        //cout << ">>" << line << "<<" << endl;


//Parameter         //Member der Klasse
void CCustomer::addAccount(CAccount *account)
{
    accountList[zaehler]=account;
    zaehler++;
}


CCustomer::CCustomer(long id, string name, CDate birthday, CAdress address)
    :id (id), name (name), birthday (birthday), address (address), zaehler(0) {}

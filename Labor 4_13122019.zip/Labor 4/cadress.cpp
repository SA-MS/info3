#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cstdio>
#include "cadress.h"
using namespace std;

void CAdress::print()
{
    printf("%s\n%s  %s\n", street.c_str(), postcode.c_str(), town.c_str());
}

// -------------------------- Konstruktoren -----------------------------------------

// Kein Standardkonstruktor

CAdress::CAdress(string street, string postcode, string town)
    :street (street), postcode (postcode), town (town) {}

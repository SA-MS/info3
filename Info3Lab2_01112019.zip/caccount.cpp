#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <iostream>
#include "caccount.h"
using namespace std;
#include "ccustomer.h"

class CCustomer;

void CAccount::print()
{
    printf("%s  (Kd-Nr.: %ld)\n", customer->getName().c_str(), customer->getId());
    printf("IBAN: ");
    printiban();
    //printf("%s \n", iban.c_str());
    printf("\nKontostand: ");
    balance.print();
//    name.print();
}

// FÜR IBAN ALLE 4 ZEICHEN GETRENNT MODULO 4

void CAccount::printiban()
{
 for(int k=0; k<iban.length(); k++)
  {
   if(k>0&&k%4==0)
   {printf(" ");}
    printf("%c", iban[k]);
   }
}


// Standardkonstruktor
CAccount::CAccount()
    :iban ("DE123456781234567890"), balance (150.0){}

// Konstruktor
CAccount::CAccount(string iban, CCustomer *customer ,CMoney balance)
    :iban (iban), balance (balance), customer (customer)
{
    customer->addAccount(this);
}

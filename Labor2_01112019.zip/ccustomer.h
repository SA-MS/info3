#ifndef CCUSTOMER_H
#define CCUSTOMER_H

#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <iostream>
#include "cadress.h"
#include "caccount.h"
#include "cmoney.h"
#include "cdate.h"
#define MAXACCOUNTS 10
using namespace std;

class CAccount;
class CAdress;

class CCustomer
{
private:
    long int id;
    string name;
    CDate birthday;
    CAdress address;
    CAccount *accountList[MAXACCOUNTS];
    int zaehler;

public:
    CCustomer();
    CCustomer(long int id, string name, CDate birthday, CAdress address);

    void setId(long int id)
    {
        this->id=id;
    }
    long int getId()
    {
        return id;
    }

    void setName(string name)
    {
        this->name=name;
    }
    string getName()
    {
        return name;
    }

    void setBirthday(CDate birthday)
    {
        this->birthday=birthday;
    }
    CDate getBirthday()
    {
        return birthday;
    }

    void setAdress(CAdress address)
    {
        this->address=address;
    }
    CAdress getAdress()
    {
        return address;
    }

    void addAccount(CAccount *accountList);
//    CAccount getAccount()


    void print();
};

#endif

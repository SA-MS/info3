#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cstring>
#include "ccustomer.h"
#include "caccount.h"



using namespace std;
class CAccount;
void CCustomer::print()
{
    printf("%s  (Kd-Nr.: %ld)\n", name.c_str(), id);
    address.print();
    printf("\ngeboren am: ");
    birthday.print();
    printf("\nKonten: ");

    for(int i=0; i<zaehler; i++)
    {
      printf("\n - Kontonr.: ");
      accountList[i]->printiban();
 //   printf("%s", accountList[i]/*customer->addAccount().c_str()*/);
    }
//    iban.print();
}
//Parameter         //Member der Klasse
void CCustomer::addAccount(CAccount *account)
{
    accountList[zaehler]=account;
    zaehler++;
}

CCustomer::CCustomer()
    :id (12345), name("Max Mustermann"), birthday(01,01,2001), address("Beispielstrasse","12345","Berlin") {}

CCustomer::CCustomer(long id, string name, CDate birthday, CAdress address)
    :id (id), name (name), birthday (birthday), address (address), zaehler(0) {}

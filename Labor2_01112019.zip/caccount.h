#ifndef CACCOUNT_H
#define CACCOUNT_H
#include <cstring>
#include <iostream>
#include <cstdio>
using namespace std;
#include "cmoney.h"
#include "ccustomer.h"

/*
Muss auf CMoney balance zugreifen
balance besteht aus amount aus CMoney
Bezug zu {CCustomer *customer}
Bezug zu {CBooking *bookingList[]}
*/

class CCustomer;

class CAccount
{
private:
    string iban;
    CMoney balance;
    CCustomer *customer;

public:
    CAccount();
    CAccount(string iban,CCustomer *customer ,CMoney balance);

    void setIban(string iban)
    {
        this->iban=iban;
    }
    string getIban()
    {
        return iban;
    }

    void setBalance(CMoney balance)
    {
        this->balance=balance;
    }
    CMoney getBalance()
    {
        return balance;
    }


    void setCustomer(CCustomer* customer)
    {
        this->customer=customer;
    }
    CCustomer* getCustomer()
    {
        return customer;
    }

/*    void setName(CCustomer name)
    {
      this->name=name;
    }
    CCustomer getName()
    {
      return name;
    } */

 /*   void setId(CCustomer id)
    {
      this->id=id;
    }
    CCustomer getId()
    {
      return id;
    } */

    void printiban();

    void print();
};


#endif
